const level = ['#445069', '#9BABB8', '#75C2F6', '#FFBB5C', '#BEADFA', '#FF9B9B', '#FF6969']

module.exports = level